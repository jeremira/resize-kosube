module JMESPath
  # @api private
  module Nodes
    Pipe = Subexpression
  end
end
