module JMESPath
  # @api private
  module Nodes
    Index = Field
  end
end
