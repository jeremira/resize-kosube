# frozen_string_literal: true

module HTTParty
  VERSION = '0.20.0'
end
