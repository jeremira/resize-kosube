module Vips
  # The type of binary complex operation to perform on an image. See
  # {Image#complex2}.
  #
  # * ':cross_phase' cross phase

  class OperationComplex2 < Symbol
  end
end
