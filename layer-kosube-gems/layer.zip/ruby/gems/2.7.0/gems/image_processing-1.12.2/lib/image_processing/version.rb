module ImageProcessing
  VERSION = "1.12.2"
end
