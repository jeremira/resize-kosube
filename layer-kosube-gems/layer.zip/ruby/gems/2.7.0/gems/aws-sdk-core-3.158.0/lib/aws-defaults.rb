# frozen_string_literal: true

require_relative 'aws-defaults/default_configuration'