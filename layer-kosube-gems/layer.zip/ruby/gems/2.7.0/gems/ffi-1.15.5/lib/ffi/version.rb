module FFI
  VERSION = '1.15.5'
end
