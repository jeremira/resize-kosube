module Vips
  VERSION = "2.1.4"
end
