# frozen_string_literal: true

# utility classes
require 'aws-sdk-sts/presigner'
